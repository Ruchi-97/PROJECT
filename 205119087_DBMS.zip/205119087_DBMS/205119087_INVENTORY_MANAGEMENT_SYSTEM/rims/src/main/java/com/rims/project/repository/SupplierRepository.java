package com.rims.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rims.project.domain.Supplier;

@Repository
public interface SupplierRepository extends JpaRepository<Supplier,Integer> {

	List<Supplier> findByuserid(int userid);
}
