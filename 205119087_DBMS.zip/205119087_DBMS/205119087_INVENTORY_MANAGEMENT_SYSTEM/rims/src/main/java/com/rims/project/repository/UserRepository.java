package com.rims.project.repository;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.rims.project.domain.User;

import org.springframework.data.repository.CrudRepository;


@Component
@Repository
public interface UserRepository extends CrudRepository<User,Integer> {

	User findByUserName(String username);
}
