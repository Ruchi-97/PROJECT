package com.rims.project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rims.project.domain.Product;
import com.rims.project.repository.ProductRepository;


@Service
public class ProductService {

	@Autowired
	private ProductRepository repo;
	
	public void saveProduct(Product product)
	{
		repo.save(product);
	}
	
	public Product findByProductPrefix(String prefix,int userid)
	{
		return repo.findByProductPrefix(prefix,userid);
	}
	
	public List<Product> findByUserID(int userid)
	{
		return repo.findByuserid(userid);
	}
	
	public Optional<Product> findById(int id)
	{
		return repo.findById(id);
	}
	
}
