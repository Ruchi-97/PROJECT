package com.rims.project.Controller;

import java.lang.reflect.Array;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.rims.project.domain.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.parameters.P;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rims.project.dto.ProductDTO;
import com.rims.project.dto.SupplierDTO;
import com.rims.project.service.BillService;
import com.rims.project.service.ProductService;
import com.rims.project.service.SupplierService;
import com.rims.project.service.UserService;

@Controller
@Component
public class InventoryController {

	@Autowired
	public UserService userService;
	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	@Autowired
	public ProductService productService;
	
	@Autowired
	public SupplierService supplierService;
	
	@Autowired
	public BillService billService;
	
	@PostMapping(path="/addUser")
	public ModelAndView addUser(@RequestParam String name,String password, RedirectAttributes redirectAttributes,HttpServletRequest req)
	{
		User user = userService.findByUserName(name);
		ModelAndView model;
		if(user!=null)
		{
			model=new ModelAndView("redirect:signup");
			redirectAttributes.addFlashAttribute("message", "User Name Exits");
			
			return model ;
			
		}
		user=new User();
		user.setUserName(name);
		user.setUserPassword(passwordEncoder.encode(password));
		userService.addUser(user);
		model=new ModelAndView("redirect:login");
		redirectAttributes.addFlashAttribute("message", "Successfully signed up. Login Now");
		return model ;
	}
	
	@GetMapping(path="/signup")
	public String signup(HttpServletRequest req)
	{
		if(req.getRemoteUser()!=null)
			return "redirect:authenticateUser";
	
		return "SignUp";
	}
	
	@RequestMapping(path="/login")
	public String sigin(HttpServletRequest req)
	{
		if(req.getRemoteUser()!=null)
			return "redirect:authenticateUser";
		return "login";
	}
	
	
	@GetMapping(path="/error")
	public void error()
	{
		System.out.println("Error");
	}
	
	@RequestMapping(path="/")
	public String authenticateUser()
	{
		return "Home";
		
	}
	
	@GetMapping(path="/addProduct")
	public String addProductPage()
	{
		return "addProduct";
	}
	
	@PostMapping(path="/addProductDB")
	public String addProduct(ProductDTO productDTO,RedirectAttributes redirectAttributes,HttpServletRequest req)
	{
		User user = userService.findByUserName(req.getRemoteUser());
		Product product = productService.findByProductPrefix(productDTO.getProductprefix(),user.getUserID());
		
		if(product!=null)
		{
			redirectAttributes.addFlashAttribute("message", "Product with this prefix already exists");
			return "redirect:addProduct";
		}
		product = new Product(productDTO);
		
		
		product.setUserid(user.getUserID());
		productService.saveProduct(product);
		redirectAttributes.addFlashAttribute("success_message", "Product added successfully");
		return "redirect:addProduct";
	}
	
	@GetMapping(path="/addSupplier")
	public String addSupplierPage()
	{
		return "addSupplier";
	}
	
	@PostMapping(path="/addSupplierDB")
	public String addSupplier(SupplierDTO supplierDTO,RedirectAttributes redirectAttributes,HttpServletRequest req)
	{
		Supplier supplier= new Supplier(supplierDTO);
		User user = userService.findByUserName(req.getRemoteUser());
		supplier.setUserid(user.getUserID());
		supplierService.saveSupplier(supplier);
		redirectAttributes.addFlashAttribute("success_message", "Supplier added successfully");
		return "redirect:addSupplier";
	}

	@GetMapping(path="/addStock")
	public ModelAndView addStockPage(HttpServletRequest req)
	{
		User user = userService.findByUserName(req.getRemoteUser());
		List<Product> productList= productService.findByUserID(user.getUserID());
		List<Supplier> supplierList = supplierService.findByUserID(user.getUserID());
		ModelAndView model = new ModelAndView("addStock");
		model.addObject("productList", productList);
		model.addObject("supplierList", supplierList);
		return model;
	}
	
	@PostMapping(path="/addStockDB")
	public String addStock(Bill bill,HttpServletRequest req,RedirectAttributes redirectAttributes)
	{
		User user = userService.findByUserName(req.getRemoteUser());
		Optional<Product> product = productService.findById(bill.getProductid());
		if(product.isPresent())
		{
			Product pr = product.get();
			pr.setCurrentStock(pr.getCurrentStock()+bill.getStock());
			productService.saveProduct(pr);
		}
		bill.setUserid(user.getUserID());
		billService.saveBill(bill);
		redirectAttributes.addFlashAttribute("message", "Added in Stock");
		return "redirect:addStock";
	}
	
	@GetMapping(path="/viewProducts")
	public ModelAndView viewProduct(HttpServletRequest req)
	{
		ModelAndView model = new ModelAndView("viewProducts");
		User user = userService.findByUserName(req.getRemoteUser());
		List<Product> productList = productService.findByUserID(user.getUserID());
		model.addObject("productList", productList);
		return model;
	}
	
	@GetMapping(path="/viewSuppliers")
	public ModelAndView viewSuppliers(HttpServletRequest req)
	{
		ModelAndView model = new ModelAndView("viewSuppliers");
		User user = userService.findByUserName(req.getRemoteUser());
		List<Supplier> supplierList = supplierService.findByUserID(user.getUserID());
		model.addObject("supplierList", supplierList);
		return model;
	}
	
	@GetMapping(path="/sellProduct")
	public ModelAndView sellProduct(HttpServletRequest req)
	{
		ModelAndView model = new ModelAndView("sellProduct");
		User user = userService.findByUserName(req.getRemoteUser());
		List<Product> productList = productService.findByUserID(user.getUserID());
		model.addObject("productList", productList);
		return model;
	}
	
	@PostMapping(path="/sellStockDB")
	public String sellStock(@RequestParam int productid,@RequestParam int stock,RedirectAttributes redirectAttributes)
	{
		Optional<Product> product = productService.findById(productid);
		if(product.isPresent())
		{
			Product pr = product.get();
			long curStock = pr.getCurrentStock();
			if(curStock<stock)
			{
				redirectAttributes.addFlashAttribute("message", "Less Stock in inventory");
			}
			else
			{
				pr.setCurrentStock(curStock-stock);
				productService.saveProduct(pr);
				redirectAttributes.addFlashAttribute("message", "Success");
			}
		}
		else
		{
			redirectAttributes.addFlashAttribute("message", "Product Doesn't exist");
		}
		
		return "redirect:sellProduct";
		
	}

	@GetMapping(path = "/getPreviousPurchases")
	public ModelAndView getPurchases(HttpServletRequest request)
	{
		Object[] previousData = billService.getPreviousData(request.getRemoteUser());
		ModelAndView model = new ModelAndView("previousPurchase");
		List<PreviousData> pre = new ArrayList<>();
		for(Object object:previousData)
		{
			Object[]objects= (Object[])object;
			PreviousData prev=new PreviousData();
			prev.setProductPrefix(objects[0].toString());
			prev.setSupplierName(objects[1].toString());
			prev.setStock(objects[2].toString());
			pre.add(prev);
		}
		model.addObject("attribute",pre);
		return model;
	}
}
