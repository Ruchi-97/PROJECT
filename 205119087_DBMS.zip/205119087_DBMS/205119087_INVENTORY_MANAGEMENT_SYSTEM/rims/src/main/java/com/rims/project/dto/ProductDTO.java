package com.rims.project.dto;

public class ProductDTO {
	private String productprefix;
	private String productName;
	private String productCompany;
	
	public String getProductprefix() {
		return productprefix;
	}
	public void setProductprefix(String productprefix) {
		this.productprefix = productprefix;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCompany() {
		return productCompany;
	}
	public void setProductCompany(String productCompany) {
		this.productCompany = productCompany;
	}
}
