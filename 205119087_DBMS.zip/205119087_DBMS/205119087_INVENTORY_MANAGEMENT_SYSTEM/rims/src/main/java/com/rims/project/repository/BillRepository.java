package com.rims.project.repository;

import com.rims.project.domain.PreviousData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.stereotype.Repository;

import com.rims.project.domain.Bill;

import java.util.List;

@Repository
public interface BillRepository extends JpaRepository<Bill,Integer>{

    @Query(nativeQuery=true,value="call getPreviousData(?1)")
    Object[] getPreviousData(String userName);
}
