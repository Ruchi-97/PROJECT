package com.rims.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rims.project.domain.Supplier;
import com.rims.project.repository.SupplierRepository;

@Service
public class SupplierService {
	
	@Autowired
	private SupplierRepository repo;
	
	public void saveSupplier(Supplier supplier)
	{
		repo.save(supplier);
	}

	public List<Supplier> findByUserID(int userid)
	{
		return repo.findByuserid(userid);
	}
}
