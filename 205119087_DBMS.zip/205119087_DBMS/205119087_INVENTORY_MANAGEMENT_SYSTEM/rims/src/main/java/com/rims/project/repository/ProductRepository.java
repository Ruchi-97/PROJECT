package com.rims.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.rims.project.domain.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product,Integer> {

	@Query(value="select * from product where product_prefix=?1 and userid=?2",nativeQuery=true)
	public Product findByProductPrefix(String prefix,int userid);
	
	public List<Product> findByuserid(int userid);
}
