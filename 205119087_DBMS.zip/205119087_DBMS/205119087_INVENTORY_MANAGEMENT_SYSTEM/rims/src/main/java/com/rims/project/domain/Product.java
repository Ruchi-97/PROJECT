package com.rims.project.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import javax.persistence.Id;
import org.springframework.stereotype.Component;

import com.rims.project.dto.ProductDTO;

@Entity
@Component
@Table(name="product")
public class Product {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private int userid;
	private String productPrefix;
	private String productName;
	private String Company;
	private long currentStock;
	public long getCurrentStock() {
		return currentStock;
	}
	public void setCurrentStock(long currentStock) {
		this.currentStock = currentStock;
	}
	public Product()
	{
		
	}
	public Product(ProductDTO productDTO)
	{
		this.Company=productDTO.getProductCompany();
		this.productName=productDTO.getProductName();
		this.productPrefix=productDTO.getProductprefix();
		this.currentStock=0;
	}
	public String getProductPrefix() {
		return productPrefix;
	}
	public void setProductPrefix(String productPrefix) {
		this.productPrefix = productPrefix;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getCompany() {
		return Company;
	}
	public void setCompany(String company) {
		this.Company = company;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}

	
	
}
