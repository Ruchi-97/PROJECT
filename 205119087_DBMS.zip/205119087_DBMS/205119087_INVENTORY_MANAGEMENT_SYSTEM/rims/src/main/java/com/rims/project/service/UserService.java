package com.rims.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.rims.project.domain.User;
import com.rims.project.repository.UserRepository;

@Service
@Component
public class UserService {

	@Autowired
	public UserRepository repo;
	
	public void addUser(User user)
	{
		repo.save(user);
	}
	
	public User findByUserName(String userName)
	{
		return repo.findByUserName(userName);
	}
}
