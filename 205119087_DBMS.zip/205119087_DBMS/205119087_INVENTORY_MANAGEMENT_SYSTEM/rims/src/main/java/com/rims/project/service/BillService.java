package com.rims.project.service;

import com.rims.project.domain.PreviousData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rims.project.domain.Bill;
import com.rims.project.repository.BillRepository;

import java.util.List;

@Service
public class BillService {

	@Autowired
	private BillRepository repo;
	
	public void saveBill(Bill bill)
	{
		repo.save(bill);
	}

	public Object[] getPreviousData(String userName)
	{
		return repo.getPreviousData(userName);
	}

}
