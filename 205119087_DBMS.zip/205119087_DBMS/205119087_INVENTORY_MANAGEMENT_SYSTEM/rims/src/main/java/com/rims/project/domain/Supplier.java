package com.rims.project.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.rims.project.dto.SupplierDTO;

@Entity
@Component
@Table(name="supplier")
public class Supplier {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private int userid;
	private String supplierName;
	private String supplierAddress;
	
	public Supplier()
	{
		
	}
	public Supplier(SupplierDTO supplierDTO)
	{
		this.supplierAddress=supplierDTO.getAddress();
		this.supplierName=supplierDTO.getSupplierName();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getSupplierAddress() {
		return supplierAddress;
	}
	public void setSupplierAddress(String supplierAddress) {
		this.supplierAddress = supplierAddress;
	}
	
	
	
}
